# Building the Docker Image

To build the Docker image simply run the `build` command and provide the tag `bmuschko/web-app:1.0.1`.

```
docker build -t bmuschko/web-app:1.0.1 .
```