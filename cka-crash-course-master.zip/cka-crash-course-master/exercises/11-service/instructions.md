# Exercise 11

The content overlaps with the curriculum of the CKAD exam. You can find the instructions and the solution in the exercises folder of the GitHub repository [bmuschko/ckad-crash-course](https://github.com/bmuschko/ckad-crash-course/tree/master/exercises/14-exposing-service).