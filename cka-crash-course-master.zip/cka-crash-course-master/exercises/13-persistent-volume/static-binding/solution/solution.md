# Solution

Create a manifest for the PersistentVolume and store it in the file `pv.yaml`.

```yaml
kind: PersistentVolume
apiVersion: v1
metadata:
  name: pv
spec:
  capacity:
    storage: 512m
  accessModes:
    - ReadWriteMany
  hostPath:
    path: /data/config
```

Create the PersistentVolume with the following command.

```
$ kubectl create -f pv.yaml
persistentvolume/pv created
$ kubectl get pv
NAME   CAPACITY   ACCESS MODES   RECLAIM POLICY   STATUS      CLAIM   STORAGECLASS   REASON   AGE
pv     512m       RWX            Retain           Available                                   12s
```

Create a manifest for the PersistentVolumeClaim and store it in the file `pvc.yaml`.

```yaml
kind: PersistentVolumeClaim
apiVersion: v1
metadata:
  name: pvc
spec:
  accessModes:
    - ReadWriteMany
  resources:
    requests:
      storage: 256m
```

Create the PersistentVolumeClaim with the following command. You will see that the storage class assigned to the PersistentVolumeClaim. Listing the PersistentVolumes will also reveal that the object has been created for your automatically.

```
$ kubectl create -f pvc.yaml
persistentvolumeclaim/pvc created
$ kubectl get pvc
NAME   STATUS   VOLUME                                     CAPACITY   ACCESS MODES   STORAGECLASS   AGE
pvc    Bound    pvc-8c5a1e6b-e8e7-4209-a6bb-c82f8537179f   256m       RWX            standard       3s
```

Create a manifest for the Pod and store it in the file `pod.yaml`.

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: app
spec:
  containers:
  - image: nginx
    name: app
    volumeMounts:
    - mountPath: "/data/app/config"
      name: configpvc
  volumes:
  - name: configpvc
    persistentVolumeClaim:
      claimName: pvc
  restartPolicy: Never
```

```
$ kubectl create -f pod.yaml
pod/app created
```

Shell into the Pod and create a file in the mounted directory.

```
$ kubectl exec app -it -- /bin/sh
# cd /data/app/config
# ls -l
total 0
# touch test.txt
# ls -l
total 0
-rw-r--r-- 1 root root 0 Dec 30 17:24 test.txt
```